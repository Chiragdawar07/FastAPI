from pydantic import BaseModel, Field, EmailStr

class PostSchema(BaseModel):
    id: int =Field(default=None)
    title: str =Field(default=None)
    content: str=Field(default=None)

    class Config:
        schema_extra={
            "example":{
                "title":"Chirag Dawar",
                "content":"Software trainee at Broadway Infotech Private Limited"
            }
        }

class UserSchema(BaseModel):
    fullname: str= Field(default=None)
    email: EmailStr= Field(default=None)
    password: str= Field(default=None)

    class Config:
        schema_extra={
            "example":{
                "fullname":"Chirag Dawar",
                "email":"dawarchirag1@gmail.com",
                "password":"Fastapi@123"
            }
        }


class UserLoginSchema(BaseModel):
    email:EmailStr= Field(default=None)
    password: str= Field(default=None)

    class Config:
        schema_extra={
            "example":{
                "email":"dawarchirag1@gmail.com",
                "password":"Fastapi@123"
            }
        }


